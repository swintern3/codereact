## The Perfect Cup ##

**The Perfect Cup** - a blog for Coffee lovers only!

![](https://github.com/bsrinath9/PerfectCup/blob/main/img/slide-1.jpg)

A members only blog for coffee lovers built in **PHP**, **MySQL**, frontend supported by **Bootstrap**,**HTML**,**JavaScript** and **AJAX**. New users can be registered by using **Register** form and will be authenticated using **MySQL** in phpmyadmin console of **WAMP** server. The user passwords are encrypted using **BCRYPT** method. The application is deployed in **Heroku** cloud platform to show demo. 

[Click here to go to the blog](https://perfectcoffee.herokuapp.com/)
